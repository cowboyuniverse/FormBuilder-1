package formbuilder.model;

public class BinderTemplateQuestion {

}
