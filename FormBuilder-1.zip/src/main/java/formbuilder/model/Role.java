package formbuilder.model;

public enum Role {
	USER, ADMIN, STAFF
}
