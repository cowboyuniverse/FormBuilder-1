
drop table block cascade;
drop table form cascade;
drop table item cascade;
drop table page cascade;
drop table pdf cascade;
drop table pdf_field cascade;
drop table pdf_field_item cascade;
drop table selection_answer cascade;
drop table selection_answer_selections cascade;
drop table selections cascade;
drop table text_answer cascade;
drop table users cascade;