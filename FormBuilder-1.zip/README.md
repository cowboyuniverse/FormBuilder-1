# CS5220
Legal Form-builder project

[Refresher on using git and github](https://try.github.io/levels/1/challenges/1)

Git cheatsheet
![Cheat Sheet](https://s-media-cache-ak0.pinimg.com/originals/25/9a/ca/259aca7a772f06f110c73f2740c29a65.png)

### Contributing

Always make certain that your branch is up-to-date with the `dev` branch.

**IMPORTANT:** Please read guidelines on collaborating/contributing here:
* [Branching and Contributing](https://github.com/melaniemkwon/CS5220/wiki/%5Bgithub%5D-Branching-&-Contributing)
